#!/bin/bash
echo 'Starte dynamische Analyse...'
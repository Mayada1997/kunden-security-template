# Beispiel-Skript zur statischen Analyse
print('Statische Analyse läuft...')